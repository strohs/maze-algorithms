mod recursive_division;
mod recursive_backtracking;
mod prims;
mod maze;
mod direction;
mod binary_tree;


fn main() {
    println!("Hello, world!");
}
